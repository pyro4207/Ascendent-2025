// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import static edu.wpi.first.units.Units.*;

import com.ctre.phoenix6.SignalLogger;
import com.ctre.phoenix6.mechanisms.swerve.LegacySwerveRequest.FieldCentric;
import com.ctre.phoenix6.swerve.SwerveModule.DriveRequestType;
import com.ctre.phoenix6.swerve.SwerveRequest;
import com.pathplanner.lib.auto.AutoBuilder;
import com.pathplanner.lib.auto.NamedCommands;

import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.util.Units;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.Commands;
import edu.wpi.first.wpilibj2.command.InstantCommand;
import edu.wpi.first.wpilibj2.command.button.CommandXboxController;
import edu.wpi.first.wpilibj2.command.button.JoystickButton;
import edu.wpi.first.wpilibj2.command.sysid.SysIdRoutine.Direction;
import frc.robot.ConstantsOther.ArmConstants;
import frc.robot.ConstantsOther.ElevatorConstants;
import frc.robot.Utils.TargetPosition;
import frc.robot.Commands.Elevator_Arm_Movement;
import frc.robot.Commands.Elevator_Arm_Movementnonparralel;
import frc.robot.Commands.Arm.PlaceArm;
import frc.robot.Commands.Elevator.Plunge;
import frc.robot.generated.TunerConstants;
import frc.robot.subsystems.Arm;
import frc.robot.subsystems.Climber;
import frc.robot.subsystems.CommandSwerveDrivetrain;
import frc.robot.subsystems.Elevator;
import frc.robot.subsystems.HFCameraSetSwitchable2025;
import frc.robot.subsystems.HFLaserCan;
import frc.robot.subsystems.HFPhotonCamera;






public class RobotContainer {

    

    private int curDriveMode = ConstantsOther.DriveMode.FIELDCENTRIC;


    //start swerve added stuff----------------------------------------------------
    private final double MAXSPEED = TunerConstants.kSpeedAt12Volts.in(MetersPerSecond); // kSpeedAt12Volts desired top speed
    private double MaxAngularRate = RotationsPerSecond.of(0.75).in(RadiansPerSecond); // 3/4 of a rotation per second max angular velocity




    /* Setting up bindings for necessary control of the swerve drive platform */
    private final SwerveRequest.FieldCentric fieldCentricDrive = new SwerveRequest.FieldCentric()
            .withDeadband(MAXSPEED * 0.1).withRotationalDeadband(MaxAngularRate * 0.1) // Add a 10% deadband
            .withDriveRequestType(DriveRequestType.OpenLoopVoltage); // Use open-loop control for drive motors
    private final SwerveRequest.RobotCentric robotCentricDrive = new SwerveRequest.RobotCentric()
            .withDeadband(MAXSPEED * 0.1).withRotationalDeadband(MaxAngularRate * 0.1) // Add a 10% deadband
            .withDriveRequestType(DriveRequestType.OpenLoopVoltage); // Use open-loop control for drive motors
    private final SwerveRequest.SwerveDriveBrake brake = new SwerveRequest.SwerveDriveBrake();
    private final SwerveRequest.PointWheelsAt point = new SwerveRequest.PointWheelsAt();

    private final Telemetry logger = new Telemetry(MAXSPEED);

    private final CommandXboxController joystickDriver = new CommandXboxController(0);
    private final Joystick joystickAssistant = new Joystick(1);

    public final CommandSwerveDrivetrain drivetrain = TunerConstants.createDrivetrain();
    // end swerve added stuff

   public static Climber mClimber =  new Climber();
    public static Elevator mElevator = new Elevator(ElevatorConstants.leftID, ElevatorConstants.rightID);
    public static Arm mArm = new Arm(ArmConstants.armId);
    public static HFLaserCan mLaserCan = new HFLaserCan();
    public static HFPhotonCamera mPhotonCamera = null;// new HFPhotonCamera();
    public static HFCameraSetSwitchable2025 mSwitchableCam = new HFCameraSetSwitchable2025(3);

    public static String side = "Right";

    public static TargetPosition CurrentPosition = ElevatorConstants.target[ElevatorConstants.Level1];
    
    static Pose2d previousPhotonVisionPos = new Pose2d(0,0, new Rotation2d(0));



    private final SendableChooser<Command> autoChooser;

    public RobotContainer() {
        
        NamedCommands.registerCommand("Elevator Level 4", new Elevator_Arm_Movement(ElevatorConstants.target[ElevatorConstants.Level4]));
        NamedCommands.registerCommand("Elevator Level 3", new Elevator_Arm_Movement(ElevatorConstants.target[ElevatorConstants.Level3]));
        NamedCommands.registerCommand("Elevator Level 2", new Elevator_Arm_Movement(ElevatorConstants.target[ElevatorConstants.Level2]));
        NamedCommands.registerCommand("Elevator Level 1", new Elevator_Arm_Movementnonparralel(ElevatorConstants.target[ElevatorConstants.Level1]));
        NamedCommands.registerCommand("Elevator Intake", new Elevator_Arm_Movement(ElevatorConstants.target[ElevatorConstants.Intake]));
        NamedCommands.registerCommand("Set Side Right", new InstantCommand(()->SetSide("Right")));
        NamedCommands.registerCommand("Set Side Left", new InstantCommand(()->SetSide("Left")));
        NamedCommands.registerCommand("Elevator Plunge", new Plunge());
        NamedCommands.registerCommand("Arm Place", new PlaceArm(mArm));
        NamedCommands.registerCommand("setpos", new InstantCommand(()->setcameraposition()));
        NamedCommands.registerCommand("Algae Low", new Elevator_Arm_Movement(ElevatorConstants.target[ElevatorConstants.AlgaeLow]));
        NamedCommands.registerCommand("ALgae High", new Elevator_Arm_Movement(ElevatorConstants.target[ElevatorConstants.AlgaeHigh]));

        autoChooser = AutoBuilder.buildAutoChooser("Tests");
        SmartDashboard.putData("Auto Mode", autoChooser);
        
        configureBindings();
        SignalLogger.enableAutoLogging(false);
    }

    private static double scaleValue(double d) {
        return Math.signum(d)*d*d;
    }
    private void configureBindings() {
        System.out.println("testing!!!!!!!!!!!!!!!!!!!!!!1");
        //begin swerve added stuff-----------------------------------------------
        // Note that X is defined as forward according to WPILib convention,
        // and Y is defined as to the left according to WPILib convention.
        boolean useSquared = true;
        if(useSquared) {
            drivetrain.setDefaultCommand(
                // Drivetrain will execute this command periodically
                drivetrain.applyRequest(() ->
                        fieldCentricDrive.withVelocityX(-RobotContainer.scaleValue(joystickDriver.getLeftY()) *.6 * MAXSPEED) // Drive forward with negative Y (forward)
                        .withVelocityY(-RobotContainer.scaleValue(joystickDriver.getLeftX())*.6 * MAXSPEED) // Drive left with negative X (left)
                        .withRotationalRate((-joystickDriver.getRightX() * .6)* MaxAngularRate) // Drive counterclockwise with negative X (left)
                    )
            );
        } else{

                drivetrain.setDefaultCommand(
                    // Drivetrain will execute this command periodically
                    drivetrain.applyRequest(() ->
                            fieldCentricDrive.withVelocityX((-joystickDriver.getLeftY()*.6) * MAXSPEED) // Drive forward with negative Y (forward)
                            .withVelocityY((-joystickDriver.getLeftX()*.6) * MAXSPEED) // Drive left with negative X (left)
                            .withRotationalRate((-joystickDriver.getRightX() * .6)* MaxAngularRate) // Drive counterclockwise with negative X (left)
                        )
                );
        }


        // joystickDriver.a().whileTrue(drivetrain.applyRequest(() -> brake));
       /*  joystickDriver.y().whileTrue(drivetrain.applyRequest(() ->
            point.withModuleDirection(new Rotation2d(-joystickDriver.getLeftY(), -joystickDriver.getLeftX()))
        )); */

        // Run SysId routines when holding back/start and X/Y.
        // Note that each routine should be run exactly once in a single log.
     /*    joystick.back().and(joystick.y()).whileTrue(drivetrain.sysIdDynamic(Direction.kForward));
        joystick.back().and(joystick.x()).whileTrue(drivetrain.sysIdDynamic(Direction.kReverse));
        joystick.start().and(joystick.y()).whileTrue(drivetrain.sysIdQuasistatic(Direction.kForward));
        joystick.start().and(joystick.x()).whileTrue(drivetrain.sysIdQuasistatic(Direction.kReverse));
*/
        // reset the field-centric heading on left bumper press
     //   joystickDriver.
        joystickDriver.y().onTrue(drivetrain.runOnce(() -> drivetrain.seedFieldCentric()));

        drivetrain.registerTelemetry(logger::telemeterize);
        //end swerve added stuff
        joystickDriver.x().onTrue(new InstantCommand(()->mSwitchableCam.setCamera(0, false)));
//        joystickDriver.rightBumper().onTrue(new InstantCommand(()->setDriveMode(ConstantsOther.DriveMode.ROBOTCENTRIC)));
  //      joystickDriver.rightBumper().onFalse(new InstantCommand(()->setDriveMode(ConstantsOther.DriveMode.FIELDCENTRIC)));

        if(mClimber != null) {
            //POV 0 = up, 90=right, 180=down, 270=left 
            joystickDriver.leftBumper().onTrue(new InstantCommand(()->mClimber.leftUp()));
            joystickDriver.leftBumper().onFalse(new InstantCommand(()->mClimber.stop()));

            joystickDriver.leftTrigger().onTrue(new InstantCommand(()->mClimber.leftDown()));
            joystickDriver.leftTrigger().onFalse(new InstantCommand(()->mClimber.stop()));

            joystickDriver.rightBumper().onTrue(new InstantCommand(()->mClimber.rightUp()));
            joystickDriver.rightBumper().onFalse(new InstantCommand(()->mClimber.stop()));

            joystickDriver.rightTrigger().onTrue(new InstantCommand(()->mClimber.rightDown()));
            joystickDriver.rightTrigger().onFalse(new InstantCommand(()->mClimber.stop()));

            joystickDriver.b().onTrue(new InstantCommand(()->mClimber.lock()));

            

//            joystick.leftBumper().onFalse(new InstantCommand(()->mClimber.stop()));
  //          joystick.leftBumper().onFalse(new InstantCommand(()->mClimber.stop()));
//                   new JoystickButton(driver, 4).onTrue(new InstantCommand(() -> mClimber.up()));
  //               new JoystickButton(driver, 5).onTrue(new InstantCommand(() -> mClimber.down()));
        }
        if(mElevator != null) {
            new JoystickButton(joystickAssistant, 2).onTrue(new Elevator_Arm_Movementnonparralel(ElevatorConstants.target[ElevatorConstants.Level1]));
            new JoystickButton(joystickAssistant, 3).onTrue(new Elevator_Arm_Movement(ElevatorConstants.target[ElevatorConstants.Level2]));
            new JoystickButton(joystickAssistant, 4).onTrue(new Elevator_Arm_Movement(ElevatorConstants.target[ElevatorConstants.Level3]));
            new JoystickButton(joystickAssistant, 5).onTrue(new Elevator_Arm_Movement(ElevatorConstants.target[ElevatorConstants.Level4]));
            new JoystickButton(joystickAssistant, 7).onTrue(new Elevator_Arm_Movementnonparralel(ElevatorConstants.target[ElevatorConstants.Intake]));
            //new JoystickButton(joystickAssistant, 10).onTrue(new Elevator_Arm_Movement(ElevatorConstants.target[ElevatorConstants.Start]));
            new JoystickButton(joystickAssistant, 1).onTrue(new InstantCommand(()->SetSide("Left")));
            new JoystickButton(joystickAssistant, 6).onTrue(new InstantCommand(()->SetSide("Right")));
            new JoystickButton(joystickAssistant, 8).onTrue(new Plunge());
            new JoystickButton(joystickAssistant, 9).onTrue(new Elevator_Arm_Movement(ElevatorConstants.target[ElevatorConstants.AlgaeHigh]));
            new JoystickButton(joystickAssistant, 10).onTrue(new Elevator_Arm_Movement(ElevatorConstants.target[ElevatorConstants.AlgaeLow]));

            joystickDriver.povDown().onTrue(new InstantCommand(()->mElevator.bumpUp()));
            joystickDriver.povUp().onTrue(new InstantCommand(()->mElevator.bumpDown()));

            joystickDriver.povLeft().onTrue(new InstantCommand(()->mArm.bumpUp()));
            joystickDriver.povRight().onTrue(new InstantCommand(()->mArm.bumpDown()));
        }

        if(mArm != null) {
            joystickDriver.a().onTrue(new PlaceArm(mArm));
        }

 

    }

    public Command getAutonomousCommand() {
        return autoChooser.getSelected();
    }

    public void switchDriveMode() {
        System.out.println("Drive Mode SWAP!!!!!!!!!!!!!!!!!!!!!!");
        if (curDriveMode == ConstantsOther.DriveMode.FIELDCENTRIC) {
            setDriveMode(ConstantsOther.DriveMode.ROBOTCENTRIC);
        } else {
            setDriveMode(ConstantsOther.DriveMode.FIELDCENTRIC);
        }

    }


    public void setDriveMode(int driveMode) {
        if (driveMode == ConstantsOther.DriveMode.ROBOTCENTRIC) {
            drivetrain.setDefaultCommand(
            // Drivetrain will execute this command periodically
                drivetrain.applyRequest(() ->
                    robotCentricDrive.withVelocityX(-joystickDriver.getLeftY() * MAXSPEED) // Drive forward with negative Y (forward)
                    .withVelocityY(-joystickDriver.getLeftX() * MAXSPEED) // Drive left with negative X (left)
                    .withRotationalRate(-joystickDriver.getRightX() * MaxAngularRate) // Drive counterclockwise with negative X (left)
                )
            );
            SmartDashboard.putString("DriveMode","RobotCentric");
        }
        else {   // driveMode == ConstantsOther.DriveMode.FIELDCENTRIC;
            drivetrain.setDefaultCommand(
            // Drivetrain will execute this command periodically
            drivetrain.applyRequest(() ->
                fieldCentricDrive.withVelocityX(-joystickDriver.getLeftY() * MAXSPEED) // Drive forward with negative Y (forward)
                    .withVelocityY(-joystickDriver.getLeftX() * MAXSPEED) // Drive left with negative X (left)
                    .withRotationalRate(-joystickDriver.getRightX() * MaxAngularRate) // Drive counterclockwise with negative X (left)
                )
            );
            SmartDashboard.putString("DriveMode","FieldCentric");
        }
        curDriveMode = driveMode;
    }

    public static void SetSide(String newside) {
        side = newside;
        SmartDashboard.putString("Direction", side);
        if (newside == "Left") {
            mSwitchableCam.setCamera(1, false);
        }
        else {
            mSwitchableCam.setCamera(2, false);
        }
    }

    public static void SetCurPos(TargetPosition pos) {
        CurrentPosition = pos;
    }
    
    public void setcameraposition() {
    if (mPhotonCamera != null) {
      var driveState = drivetrain.getState();
      double headingDeg = driveState.Pose.getRotation().getDegrees();
      double omegaRps = Units.radiansToRotations(driveState.Speeds.omegaRadiansPerSecond);

      

      //LimelightHelpers.SetRobotOrientation("limelight", headingDeg, 0, 0, 0, 0, 0);
     var photonCamMeasurement = RobotContainer.mPhotonCamera.getEstimatedGlobalPose(previousPhotonVisionPos);
      if (photonCamMeasurement != null) {
            SmartDashboard.putString("Camera pose auto", photonCamMeasurement.estimatedPose.toPose2d().toString());
            drivetrain.addVisionMeasurement(photonCamMeasurement.estimatedPose.toPose2d(), mPhotonCamera.lastLatency);
            previousPhotonVisionPos = photonCamMeasurement.estimatedPose.toPose2d();
      }
      else {
           SmartDashboard.putString("Camera pose auto", "none");
      }
    }
  }
}
