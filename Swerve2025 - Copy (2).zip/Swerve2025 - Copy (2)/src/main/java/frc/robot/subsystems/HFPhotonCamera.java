// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.subsystems;

import edu.wpi.first.apriltag.AprilTagFieldLayout;
import edu.wpi.first.apriltag.AprilTagFields;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation3d;
import edu.wpi.first.math.geometry.Transform3d;
import edu.wpi.first.math.geometry.Translation3d;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

import java.util.Optional;

import org.photonvision.EstimatedRobotPose;
import org.photonvision.PhotonCamera;
import org.photonvision.PhotonPoseEstimator;
import org.photonvision.PhotonPoseEstimator.PoseStrategy;
import org.photonvision.targeting.PhotonPipelineResult;
import org.photonvision.targeting.PhotonTrackedTarget;


/** Add your docs here. */
public class HFPhotonCamera{
    static AprilTagFieldLayout aprilTagFieldLayout = AprilTagFieldLayout.loadField(AprilTagFields.kDefaultField);
    
        //Forward Camera
    public PhotonCamera cam_left = new PhotonCamera("Left_AprilTag");
    public PhotonCamera cam_right = new PhotonCamera("Right_AprilTag");
//    Transform3d robotToCam = new Transform3d(new Translation3d(0.15, -0.125, 0.6096), new Rotation3d(0,0,-Math.PI/2)); //Cam mounted facing forward, half a meter forward of center, half a meter up from center.
    Transform3d robotToCam = new Transform3d(new Translation3d(0.152, -0.143, 0.6096), new Rotation3d(0,0,-Math.PI/2)); //Cam mounted facing forward, half a meter forward of center, half a meter up from center.
            
        // Construct PhotonPoseEstimator
    public PhotonPoseEstimator photonPoseEstimator = new PhotonPoseEstimator(aprilTagFieldLayout, PoseStrategy.MULTI_TAG_PNP_ON_COPROCESSOR, robotToCam);

    

    public double lastLatency = 0;
        
    public EstimatedRobotPose getEstimatedGlobalPose(Pose2d prevEstimatedRobotPose) {
        photonPoseEstimator.setReferencePose(prevEstimatedRobotPose);
        PhotonPipelineResult result = cam_left.getLatestResult();
        if (result.hasTargets()) {
            lastLatency = result.getTimestampSeconds();
            try {
            return photonPoseEstimator.update(result).get();
            } 
            catch(Exception e) {
                return null;
            }
        }
        else {
            return null;
        }
    }

    

}
