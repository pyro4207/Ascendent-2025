// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.subsystems;

import au.grapplerobotics.ConfigurationFailedException;
import au.grapplerobotics.LaserCan;
import au.grapplerobotics.interfaces.LaserCanInterface.Measurement;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

public class HFLaserCan extends SubsystemBase {

  private LaserCan lc = null;
  private long startOutOfRangeTime = 0;
  private int outOfRangeCounter = 0;

  /** Creates a new HFLaserCan. */
  public HFLaserCan() {
    lc = new LaserCan(0);
    startOutOfRangeTime = System.currentTimeMillis();
    outOfRangeCounter = 0;
    // Optionally initialise the settings of the LaserCAN, if you haven't already done so in GrappleHook
    try {
      lc.setRangingMode(LaserCan.RangingMode.SHORT);
      lc.setRegionOfInterest(new LaserCan.RegionOfInterest(8, 8, 16, 16));
      lc.setTimingBudget(LaserCan.TimingBudget.TIMING_BUDGET_33MS);
    } catch (ConfigurationFailedException e) {
      System.out.println("Configuration failed! " + e);
    }
  }

  public double Distance() {
    return lc.getMeasurement().distance_mm;
  }
  
  @Override
  public void periodic() {
    // This method will be called once per scheduler run

    LaserCan.Measurement measurement = lc.getMeasurement();
    if (measurement != null && measurement.status == LaserCan.LASERCAN_STATUS_VALID_MEASUREMENT) {
      SmartDashboard.putNumber("LaserCan", measurement.distance_mm);
      outOfRangeCounter = 0;
    } else {
      if(outOfRangeCounter == 0) {
          System.out.println("Elevator out of range!");
          startOutOfRangeTime = System.currentTimeMillis();
      } else if(outOfRangeCounter %25 == 0) {  // increase 10 if still too many messages
          System.out.println("Elevator out of range " + (System.currentTimeMillis() - startOutOfRangeTime) + "ms");
        // You can still use distance_mm in here, if you're ok tolerating a clamped value or an unreliable measurement.
      }
      outOfRangeCounter++;
      SmartDashboard.putNumber("LaserCan", -4207);
    }
  }
}
