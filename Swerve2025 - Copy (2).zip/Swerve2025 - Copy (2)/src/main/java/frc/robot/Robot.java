// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import org.photonvision.EstimatedRobotPose;
import org.photonvision.PhotonCamera;

import com.ctre.phoenix6.SignalLogger;
import com.ctre.phoenix6.swerve.SwerveDrivetrain.SwerveDriveState;

import edu.wpi.first.apriltag.AprilTag;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.util.Units;
import edu.wpi.first.util.sendable.Sendable;
import edu.wpi.first.util.sendable.SendableBuilder;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.CommandScheduler;
import frc.robot.subsystems.AprilTagCamTestVision;
import frc.robot.subsystems.Elevator;
import frc.robot.subsystems.HFPhotonCamera;

public class Robot extends TimedRobot {
  private Command m_autonomousCommand;
  private final AprilTagCamTestVision vision = new AprilTagCamTestVision();
  private final RobotContainer m_robotContainer;

  

  public Robot() {
    m_robotContainer = new RobotContainer();
  }

  static Pose2d previousPhotonVisionPos = new Pose2d(0,0, new Rotation2d(0));

  @Override
  public void robotPeriodic() {
    CommandScheduler.getInstance().run(); 
    SmartDashboard.putNumber("Match Time", DriverStation.getMatchTime());

    //checkVision();

    /* if (m_robotContainer.mPhotonCamera != null) {
      //LimelightHelpers.SetRobotOrientation("limelight", headingDeg, 0, 0, 0, 0, 0);
     var llMeasurement = RobotContainer.mPhotonCamera.getEstimatedGlobalPose(previousPhotonVisionPos);
      if (llMeasurement != null) {
        SmartDashboard.putString("Camera pose", llMeasurement.estimatedPose.toPose2d().toString());
        previousPhotonVisionPos = llMeasurement.estimatedPose.toPose2d();
      }
      else {
        SmartDashboard.putString("Camera pose", "none");
      }
    } */

    
     // Correct pose estimate with vision measurements


    if (m_robotContainer.side == "Left") {
      SmartDashboard.putBoolean("Left", true);
      SmartDashboard.putBoolean("Right", false);
    }
    else {
      SmartDashboard.putBoolean("Left", false);
      SmartDashboard.putBoolean("Right", true);
    }
  }

  @Override
  public void disabledInit() {
    SignalLogger.enableAutoLogging(false);

  }

  @Override
  public void disabledPeriodic() {}

  @Override
  public void disabledExit() {}

  @Override
  public void autonomousInit() {
    if (m_robotContainer.mElevator != null) {
      //m_robotContainer.mElevator.holdCurrent();
      m_robotContainer.mElevator.set(0);
    }
    if(m_robotContainer.mArm != null) {
      //m_robotContainer.mArm.holdAtCurrentPosition();
      m_robotContainer.mArm.updatePID();
      //m_robotContainer.mArm.runToPosition(.5);
      m_robotContainer.mArm.set(0);
    }

    

    m_autonomousCommand = m_robotContainer.getAutonomousCommand();



    if (m_autonomousCommand != null) {
      m_autonomousCommand.schedule();
    }

  }

  @Override
  public void autonomousPeriodic() {
    
  }

  @Override
  public void autonomousExit() {}

  @Override
  public void teleopInit() {
      if (m_autonomousCommand != null) {
        m_autonomousCommand.cancel();
      }
      m_robotContainer.setDriveMode(ConstantsOther.DriveMode.FIELDCENTRIC);

      if (m_robotContainer.mElevator != null) {
        m_robotContainer.mElevator.set(0);
        if (m_robotContainer.mLaserCan.Distance() != 0) {
          m_robotContainer.mElevator.ChangeEncoderOffset(m_robotContainer.mLaserCan.Distance());
        }
        m_robotContainer.mElevator.holdCurrent();

      }
      if(m_robotContainer.mArm != null) {
        m_robotContainer.mArm.updatePID();
        m_robotContainer.mArm.set(0);
        m_robotContainer.mArm.holdAtCurrentPosition();
        //m_robotContainer.mArm.runToPosition(.5);
      }
      if(m_robotContainer.mClimber != null) {
        m_robotContainer.mClimber.unLock();
      }
    
  }

  @Override
  public void teleopPeriodic() {
    
  }

  @Override
  public void teleopExit() {}

  @Override
  public void testInit() {
    CommandScheduler.getInstance().cancelAll();
    
  }

  @Override
  public void testPeriodic() {}

  @Override
  public void testExit() {}

  @Override
  public void simulationPeriodic() {}

  protected void checkVision() {
    vision
        .getPoseEstimates()
        .forEach(
            est -> {
              /*m_robotContainer.drivetrain.addVisionMeasurement(
                  est.pose().estimatedPose.toPose2d(), est.pose().timestampSeconds, est.stdev());*/
              SmartDashboard.putString("Cam" + est.name().toString(), est.pose().estimatedPose.toPose2d().toString());
            });

    
  }
}
